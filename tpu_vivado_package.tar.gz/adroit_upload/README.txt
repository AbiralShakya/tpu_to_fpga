TPU Bitstream Build Package for Adroit
=======================================

Files:
- tpu_basys3.edif: Synthesized netlist from Yosys
- basys3_nextpnr.xdc: FPGA constraints
- build_tpu_vivado.tcl: Automated build script

See ADROIT_VIVADO_GUI_GUIDE.md for instructions.
